
import flet as ft
import time
import openpyxl
import random
counter1=0
max1=0
deleted_numbers=[]
wb = openpyxl.reader.excel.load_workbook(filename="formuls.xlsx", data_only=True)
wb.active = 0
sheet = wb.active
formuls=0
len_meh=49
deleted_numbers=[]
numbers=[]
number=0
counterk=0
def main(page):
    a="#eb06ff"
    BG="#041955"
    page.bgcolor=BG
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    def lose():
        page.clean()
        zero()
        page.add(ft.Text("К сожалению, неверно", color="WHITE", size='60'))
        b = ft.FilledButton("Попробовать ещё раз?", on_click=btn_click, width=500, height=100, style=ft.ButtonStyle(bgcolor=ft.colors.BLUE))
        page.controls.append(b)
        page.update()
        global deleted_numbers
        deleted_numbers=[]
    def btn_click(nach):
        page.clean()
        global deleted_numbers
        global numbers
        global number
        global sheet
        numbers=[]
        deleted_YYYYYYY=[]
        while len(numbers)!=4:
            random_number=random.randint(1,formuls)
            if random_number not in deleted_YYYYYYY:
                numbers.append(random_number)
                deleted_YYYYYYY.append(random_number)
        number=random.randint(1,formuls)
        while number in deleted_numbers or number in numbers:
            number=random.randint(1,formuls)
        numbers.append(number)
        deleted_numbers.append(number)
        numbers=sorted(numbers)
        img = ft.Image(
            src=f"/picturies/"+sheet["A"+str(number+1)].value+".png",
            width=300,
            height=300,
            fit=ft.ImageFit.CONTAIN,
        )
        c1=ft.Container(
            content=img,
            bgcolor=ft.colors.PINK_500,
            width=300,
            height=300,
            border_radius=30,

        )
        ret = (ft.FilledButton("Вернуться", on_click=btn_choose, width=200, height=50))
        page.add(ft.Text("Максимум правильных ответов: "+str(max1), color="WHITE", size=30),ft.Text("Счетчик правильных ответов: "+str(counter1),color="WHITE",size=30),c1)
        b1 = ft.FilledButton(sheet["B"+str(1+numbers[0])].value, on_click=right_1, width=250, height=150, style=ft.ButtonStyle(bgcolor=ft.colors.BLUE))
        b2 = ft.FilledButton(sheet["B"+str(1+numbers[1])].value, on_click=right_2, width=250, height=150, style=ft.ButtonStyle(bgcolor=ft.colors.BLUE))
        b3 = ft.FilledButton(sheet["B"+str(1+numbers[2])].value, on_click=right_3, width=250, height=150, style=ft.ButtonStyle(bgcolor=ft.colors.BLUE))
        b4 = ft.FilledButton(sheet["B"+str(1+numbers[3])].value, on_click=right_4, width=250, height=150, style=ft.ButtonStyle(bgcolor=ft.colors.BLUE))
        b5 = ft.FilledButton(sheet["B"+str(1+numbers[4])].value, on_click=right_5, width=250, height=150, style=ft.ButtonStyle(bgcolor=ft.colors.BLUE))
        page.add(ft.Row([b1,b2,b3,b4,b5],alignment=ft.MainAxisAlignment.CENTER))
        page.add(ft.Row([ret], alignment=ft.MainAxisAlignment.START))
        page.update()
    def right_True():
        page.clean()
        plus_one(counter1)
        changing_max(counter1, max1)
        btn_click(1)
        if len(deleted_numbers)==formuls:
            win()
    def right_1(b):
        if numbers[0]==number:
            right_True()
        else:
            lose()
    def right_2(b):
        if numbers[1]==number:
            right_True()
        else:
            lose()
    def right_3(b):
        if numbers[2]==number:
            right_True()
        else:
            lose()
    def right_4(b):
        if numbers[3]==number:
            right_True()
        else:
            lose()
    def right_5(b):
        if numbers[4]==number:
            right_True()
        else:
            lose()
    def plus_one(a):
        c=a+1
        global counter1
        counter1=c
    def zero():
        c=0
        global counter1, max1
        counter1=c
    def changing_max(a,b):
        if a>b:
            b=a
            global max1
            max1=b
    def win():
        page.clean()
        page.add(ft.Text("Вы победили! Поздравляем!", color="Green999", size=55, ))
        b = ft.ElevatedButton("Не желаете попробовать ещё раз?", on_click=btn_click, width=1500)
        page.controls.append(b)
        page.update()
        zero()
        global deleted_numbers
        deleted_numbers=[]
    def btn_exit(ex):
        pass
    def btn_choose(strt):
        page.clean()
        stud=ft.FilledButton("Учащийся",on_click=btn_stud,width=300,height=100, style=ft.ButtonStyle(bgcolor=ft.colors.PINK_500))
        teach = ft.FilledButton("Учитель", on_click=btn_teach, width=300, height=100, style=ft.ButtonStyle(bgcolor=ft.colors.PINK_500))
        amat=ft.FilledButton("Любитель", on_click=btn_amat, width=300, height=100, style=ft.ButtonStyle(bgcolor=ft.colors.PINK_500))
        page.add(ft.Text("Кто вы?", color="WHITE", size=55))
        page.add(ft.Row([stud],alignment=ft.MainAxisAlignment.CENTER))
        page.add(ft.Row([teach],alignment=ft.MainAxisAlignment.CENTER))
        page.add(ft.Row([amat],alignment=ft.MainAxisAlignment.CENTER))
        page.update()
    def btn_stud(stud):
        page.clean()
        tren=ft.FilledButton("Тренажер",on_click=btn_tren,width=300,height=100, style=ft.ButtonStyle(bgcolor=ft.colors.PINK_500))
        phys_calc = ft.FilledButton("Физический калькулятор", on_click=btn_phys_calc, width=300, height=100,style=ft.ButtonStyle(bgcolor=ft.colors.PINK_500))
        bibl = ft.FilledButton("Библиоткека", on_click=btn_bibl, width=300, height=100,style=ft.ButtonStyle(bgcolor=ft.colors.PINK_500))
        neuro = ft.FilledButton("Нейросети", on_click=btn_neuro, width=300, height=100,style=ft.ButtonStyle(bgcolor=ft.colors.PINK_500))
        page.add(ft.Row([tren], alignment=ft.MainAxisAlignment.CENTER))
        page.add(ft.Row([phys_calc], alignment=ft.MainAxisAlignment.CENTER))
        page.add(ft.Row([bibl], alignment=ft.MainAxisAlignment.CENTER))
        page.add(ft.Row([neuro], alignment=ft.MainAxisAlignment.CENTER))
        page.update()
    def btn_teach(teach):
        page.clean()
        page.add(ft.Text("Находится в разработке:(", color="WHITE", size=30))
        ret = ft.ElevatedButton("Вернуться", on_click=btn_choose, width=200, height=100)
        page.add(ft.Row([ret], alignment=ft.MainAxisAlignment.START))
        page.update()
    def btn_amat(amat):
        page.clean()
        bibl = ft.ElevatedButton("Библеотека", on_click=btn_bibl, width=400, height=200)
        page.add(ft.Row([bibl],alignment=ft.MainAxisAlignment.CENTER))
        ret = ft.ElevatedButton("Вернуться", on_click=btn_choose, width=200, height=100)
        page.add(ft.Row([ret], alignment=ft.MainAxisAlignment.START))
        page.update()
    def btn_bibl(bibl):
        page.clean()
        page.add(ft.Text("Находится в разработке:(", color="Black999", size=30))
        ret = ft.ElevatedButton("Вернуться", on_click=btn_choose, width=200, height=100)
        page.add(ft.Row([ret], alignment=ft.MainAxisAlignment.START))
        page.update()
    def btn_tren(tren):
        page.clean()
        page.vertical_alignment = ft.MainAxisAlignment.NONE
        page.add(ft.Text("Выберите раздел", size=70, color="WHITE"))
        page.update()
        page.vertical_alignment = ft.MainAxisAlignment.CENTER
        meh = ft.FilledButton("Механика", on_click=btn_meh, width=300, height=50,style=ft.ButtonStyle(bgcolor=ft.colors.PINK_500))
        mol = ft.FilledButton("Молекулярная физика", on_click=btn_neuro, width=300, height=50,style=ft.ButtonStyle(bgcolor=ft.colors.PINK_500))
        elec = ft.FilledButton("Электродинамика", on_click=btn_bibl, width=300, height=50,style=ft.ButtonStyle(bgcolor=ft.colors.PINK_500))
        spec_t = ft.FilledButton("Специальная теория относительности", on_click=btn_neuro, width=300, height=50,style=ft.ButtonStyle(bgcolor=ft.colors.PINK_500))
        quant = ft.FilledButton("Квантовая физика", on_click=btn_neuro, width=300, height=50,style=ft.ButtonStyle(bgcolor=ft.colors.PINK_500))
        all_r=ft.FilledButton("Все разделы", on_click=btn_neuro, width=300, height=50,style=ft.ButtonStyle(bgcolor=ft.colors.PINK_500))
        page.add(ft.Row([meh], alignment=ft.MainAxisAlignment.CENTER))
        page.add(ft.Row([mol], alignment=ft.MainAxisAlignment.CENTER))
        page.add(ft.Row([elec], alignment=ft.MainAxisAlignment.CENTER))
        page.add(ft.Row([spec_t], alignment=ft.MainAxisAlignment.CENTER))
        page.add(ft.Row([quant], alignment=ft.MainAxisAlignment.CENTER))
        page.add(ft.Row([all_r], alignment=ft.MainAxisAlignment.CENTER))
        ret = ft.FilledButton("Вернуться", on_click=btn_choose, width=200, height=100, style=ft.ButtonStyle(bgcolor=ft.colors.PINK_500))
        page.add(ft.Row([ret], alignment=ft.MainAxisAlignment.START))
        page.update()
    def btn_phys_calc(a):
        page.clean()
        OM=ft.FilledButton("Закон Ома",  on_click=btn_phys_calc_OM, width=200, height=100, style=ft.ButtonStyle(bgcolor=ft.colors.PINK_500))
        MEN=ft.FilledButton("Закон Менделеева-Клайперона",  on_click=btn_phys_calc_MEN, width=200, height=100, style=ft.ButtonStyle(bgcolor=ft.colors.PINK_500))
        page.add(OM)
        page.add(MEN)
        page.update()
    def btn_phys_calc_MEN(a):
        page.clean()
        img = ft.Image(
            src=f"/MENDELEEV.png",
            width=300,
            height=300,
            fit=ft.ImageFit.CONTAIN,
        )
        page.add(img)
        txt_P1 = ft.TextField(label="Давление", border_color="WHITE", label_style=ft.TextStyle(color="WHITE"),
                             width=300, color="WHITE")
        txt_V = ft.TextField(label="Объем", border_color="WHITE", label_style=ft.TextStyle(color="WHITE"),
                             width=300, color="WHITE")
        txt_MU = ft.TextField(label="Молярная масса", border_color="WHITE", label_style=ft.TextStyle(color="WHITE"),
                             width=300, color="WHITE")
        txt_T = ft.TextField(label="Температура", border_color="WHITE", label_style=ft.TextStyle(color="WHITE"), width=300, color="WHITE")
        page.add(txt_P1)
        page.add(txt_V)
        page.add(txt_MU)
        page.add(txt_T)
        calcul = ft.FilledButton("Рассчитать", width=200, on_click=calc_MEN)
        page.add(calcul)
        ret = (ft.FilledButton("Вернуться", on_click=btn_choose, width=200, height=100))
        page.add(ft.Row([ret], alignment=ft.MainAxisAlignment.START))
        page.update()
    def calc_MEN(a):
        pass
    def btn_phys_calc_OM(phys_calc):
        page.clean()
        img = ft.Image(
            src=f"/OM.png",
            width=300,
            height=300,
            fit=ft.ImageFit.CONTAIN,
        )
        page.add(img)
        global txt_A
        global txt_U
        global txt_R
        global txt_P
        txt_A = ft.TextField(label="Сила тока", border_color="WHITE", label_style= ft.TextStyle(color="WHITE"), width=300, color="WHITE")
        txt_U = ft.TextField(label="Напряжение", border_color="WHITE", label_style=ft.TextStyle(color="WHITE"),width=300, color="WHITE")
        txt_R = ft.TextField(label="Сопротивление", border_color="WHITE", label_style=ft.TextStyle(color="WHITE"),width=300, color="WHITE")
        txt_P = ft.TextField(label="Мощность", border_color="WHITE", label_style=ft.TextStyle(color="WHITE"),width=300, color="WHITE")
        page.add(txt_A)
        page.add(txt_U)
        page.add(txt_R)
        page.add(txt_P)
        calcul=ft.FilledButton("Рассчитать", width=200, on_click=yyy)
        page.add(calcul)
        ret = (ft.FilledButton("Вернуться", on_click=btn_choose, width=200, height=100))
        page.add(ft.Row([ret], alignment=ft.MainAxisAlignment.START))
        page.update()

    def yyy(a):
        c=0
        fa=0
        fu=0
        fp=0
        fr=0
        if not txt_A.value:
            c+=1
            fa=1
            I=0
        else:
            I = float(txt_A.value)
        if not txt_U.value:
            c+=1
            fu=1
            U=0
        else:
            U = float(txt_U.value)
        if not txt_P.value:
            c+=1
            fp=1
            P=0
        else:
            P = float(txt_P.value)
        if not txt_R.value:
            c+=1
            fr=1
            R=0
        else:
            R = float(txt_R.value)
        if c>=3:
            page.clean()
            k=ft.Text("Введите, пожалуйста, значение"+" силы тока"*fa + " или"*fa +" сопротивления"*fr+" или"*fr+" мощности"*fp+" или"*fr+" напряжения"*fu, color="WHITE", size='20')
            page.add(k)
            page.update()
            time.sleep(2)
            btn_phys_calc_OM(a)
        else:
            U_list=[U,(P*R)**0.5,I*R,(P/I if I!=0 else 0)]
            I_list = [I,(U/R if R!=0 else 0),(P/U if U!=0 else 0),(P/R if R!=0 else 0)]
            R_list=[R,(U**2/R if R!=0 else 0),(U/I if I!=0 else 0),(P/(I**2) if I!=0 else 0)]
            P_list=[P,(U**2/R if R!=0 else 0),(I**2/R if R!=0 else 0),U*I]
            U_list=sorted(U_list)
            print(U_list)
            I_list=sorted(I_list)
            R_list=sorted(R_list)
            P_list=sorted(P_list)
            page.clean()
            NAPR=ft.Text("Напряжение: "+str("{:.2f}".format(U_list[-1])), color="WHITE", size=30,)
            SIL=ft.Text("Сила тока: "+str("{:.2f}".format(I_list[-1])), color="WHITE", size=30)
            SOPR=ft.Text("Сопротвиление: "+str("{:.2f}".format(R_list[-1])), color="WHITE", size=30)
            MOSH=ft.Text("Мощность: "+str("{:.2f}".format(P_list[-1])), color="WHITE", size=30)
            page.clean()
            img = ft.Image(
                src=f"/diagramma.png",
                width=300,
                height=300,
                fit=ft.ImageFit.CONTAIN,
            )
            page.add(img)
            page.add(SIL)
            page.add(NAPR)
            page.add(SOPR)
            page.add(MOSH)
            ret = ft.ElevatedButton("Вернуться", on_click=btn_choose, width=200, height=100)
            page.add(ft.Row([ret], alignment=ft.MainAxisAlignment.START))
            page.update()
    def btn_neuro(neuro):
        page.clean()
        page.add(ft.Text("Находится в разработке:(", color="Black999", size=30))
        ret = ft.ElevatedButton("Вернуться", on_click=btn_choose, width=200, height=100)
        page.add(ft.Row([ret], alignment=ft.MainAxisAlignment.START))
        page.update()
    def btn_meh(meh):
        global formuls
        formuls=len_meh
        page.clean()
        page.add(ft.Text("Тренажер по формулам и законам Механики", color="WHITE", size=55 ))
        nach = ft.FilledButton("Начать", on_click=btn_click, width=300)
        page.add(ft.Row([nach],alignment=ft.MainAxisAlignment.CENTER))
        ret = ft.FilledButton("Вернуться", on_click=btn_choose, width=200, height=100)
        page.update()

    strt = ft.FilledButton("Начать", on_click=btn_choose, width=300,height=100, style=ft.ButtonStyle(bgcolor=ft.colors.PINK_500))
    ex = ft.FilledButton("Выйти из приложения", on_click=btn_exit, width=300,height=100, style=ft.ButtonStyle(bgcolor=ft.colors.PINK_500))
    page.add(ft.Text("PhysicsAssistant", color="White",size=55,italic="TRUE"))
    page.controls.append(ft.Row([strt,ex],alignment=ft.MainAxisAlignment.CENTER))
    page.update()
ft.app(target=main, view=ft.AppView.WEB_BROWSER, assets_dir="assets")
